</main>
        <footer>
            <div class="container">
                <p>"Where life meets luxury, there is chocolate."</p>
            </div>
        </footer>
        <?php wp_footer(); ?>
    </body>
</html>