<section class="gallery">
    <div class="container">
        <h2>Gallery</h2>
        <div class="gallery-grid">
            <!-- Itt jönnek a képek -->
        </div>
    </div>
</section>