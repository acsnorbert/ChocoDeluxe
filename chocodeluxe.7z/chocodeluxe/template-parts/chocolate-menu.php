<section class="chocolate-menu">
    <div class="container">
        <h2>CSOKOLÁDÉ MENŰ</h2>
        
        <div class="menu-item">
            <h3>Étcsokoládé</h3>
            <p>Gazdag izvilág, magas kakaótartalommal.</p>
        </div>
        
        <div class="menu-item">
            <h3>Tejcsokoládé</h3>
            <p>Klasszikus kedvenc lágy, krémés állaggal.</p>
        </div>
        
        <!-- További menüpontok -->
    </div>
</section>