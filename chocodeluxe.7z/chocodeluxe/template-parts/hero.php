<section class="hero">
    <div class="container">
        <h1>"Where life meets luxury, there is chocolate."</h1>
    </div>
</section>