<section class="about-section">
    <div class="container">
        <h2>Üzletünkről</h2>
        <p>A Choco Deluxe egy prémium csokoládékat gyártó vállalat, mely a hagyományos receptúrákat és a legfinomabb alapanyagokat ötvözi a modern technológia vívmányaival.</p>
        <p>Célunk, hogy minden egyes falatban visszatükrözzük a minőség iránti elkötelezettségünket, és egyedülálló ízelményeket nyújtsunk vásárlóinknak.</p>
        <a href="/rolunk" class="button">BÖVEBBEN</a>
    </div>
</section>