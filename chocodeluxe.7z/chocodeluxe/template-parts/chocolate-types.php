<section class="chocolate-types">
    <div class="container">
        <h2>CSOKIFAJTÁINK</h2>
        <div class="type-list">
            <div class="type-column">
                <p>Különféle csokoládé</p>
                <p>Kávés csoki</p>
                <p>Fehér csokoládé</p>
                <p>Étcsokoládé</p>
                <p>Mogyorós Csokoládé</p>
                <p>Chik Csokoládé</p>
                <p>Rózsasán Csokoládé</p>
            </div>
        </div>
    </div>
</section>