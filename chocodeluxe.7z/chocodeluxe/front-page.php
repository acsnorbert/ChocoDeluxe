<?php get_header(); ?>

<?php get_template_part('template-parts/hero'); ?>
<?php get_template_part('template-parts/about-section'); ?>
<?php get_template_part('template-parts/chocolate-types'); ?>
<?php get_template_part('template-parts/gallery'); ?>

<?php get_footer(); ?>